# Host: localhost  (Version: 5.5.27)
# Date: 2016-02-01 17:57:14
# Generator: MySQL-Front 5.3  (Build 4.234)

/*!40101 SET NAMES latin1 */;

#
# Structure for table "t_cr_objective"
#

DROP TABLE IF EXISTS `t_cr_objective`;
CREATE TABLE `t_cr_objective` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `risk_id` varchar(100) DEFAULT NULL,
  `objective` varchar(255) DEFAULT NULL,
  `change_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# Data for table "t_cr_objective"
#

INSERT INTO `t_cr_objective` VALUES (4,'1','Objective1',1);
