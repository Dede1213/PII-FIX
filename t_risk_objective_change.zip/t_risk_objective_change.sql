# Host: localhost  (Version: 5.5.27)
# Date: 2016-02-01 17:57:04
# Generator: MySQL-Front 5.3  (Build 4.234)

/*!40101 SET NAMES latin1 */;

#
# Structure for table "t_risk_objective_change"
#

DROP TABLE IF EXISTS `t_risk_objective_change`;
CREATE TABLE `t_risk_objective_change` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `risk_id` varchar(100) DEFAULT NULL,
  `objective` varchar(255) DEFAULT NULL,
  `switch_flag` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# Data for table "t_risk_objective_change"
#

